class QuizBrain:

  def __init__(self, quest_list):
    self.quest_number=0
    self.quest_list = quest_list
    self.score = 0

  
  def next_question(self):
    curren_q = self.quest_list[self.quest_number]
    answer = input(f"Q{self.quest_number+1}: {curren_q.text} (True/False): ")
    self.check_answer(answer, curren_q.answer)
    print(f"Your current score is {self.score}/{self.quest_number} \n")
  

  def check_answer(self, answer, curren_q_answer):
    if answer.lower() == curren_q_answer.lower(): 
      print("You got it right!")
      print(f"the correct answer is {curren_q_answer}")
      self.score += 1
      self.quest_number += 1
      return True
    else:
      print("You got it wrong!")
      print(f"the correct answer is {curren_q_answer}")
      self.quest_number += 1
      return False

  def final_score(self):
    print(f"Your final score is {self.score}/{self.quest_number}") 


  def is_still_have_quest(self):
    return self.quest_number != len(self.quest_list)


