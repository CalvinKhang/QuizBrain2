from question_model import Question
from quiz_brain import QuizBrain
from data import question_data
import random 
import os 
def clear(): os.system("clear")

# quest_random = random.choice(question_data)
# quest = Question(quest_random['text'],quest_random['answer'])
# print(quest.text)
# print(quest.answer)

quest_bank = []
for quest in question_data:
  quest_bank.append(Question(quest['text'],quest['answer']))
# for i in range(len(quest_bank)):
#   print(f"{quest_bank[i].text} : {quest_bank[i].answer}")

quiz = QuizBrain(quest_bank)
while(quiz.is_still_have_quest()):
  quiz.next_question()
quiz.final_score()